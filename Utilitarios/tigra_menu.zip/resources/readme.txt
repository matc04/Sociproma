This directory contains resource files required by the welcome page.
These files are not the part of Tigra Menu script.